from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, TextAreaField
from wtforms.validators import DataRequired


class AddNewUser(FlaskForm):
    username = StringField('Login', validators=[DataRequired()])
    password = TextAreaField('Text', validators=[DataRequired()])
    submit = SubmitField('Add')
